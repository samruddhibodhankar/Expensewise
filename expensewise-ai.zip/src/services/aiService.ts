import { GoogleGenAI, Type } from "@google/genai";
import { Expense } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export const extractExpense = async (input: string | { data: string, mimeType: string }) => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: typeof input === 'string' ? input : { parts: [{ inlineData: input }] },
    config: {
      systemInstruction: "Extract Amount, Category, and Merchant. Categories: Food, Travel, Shopping, Bills, Entertainment, Health, Other. Return JSON.",
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          amount: { type: Type.NUMBER },
          category: { type: Type.STRING, enum: ["Food", "Travel", "Shopping", "Bills", "Entertainment", "Health", "Other"] },
          merchant: { type: Type.STRING }
        },
        required: ["amount", "category", "merchant"]
      }
    }
  });
  return JSON.parse(response.text || "{}");
};

export const getFinancialAdvice = async (expenses: Expense[]) => {
  const summary = expenses.map(e => `${e.merchant}: $${e.amount}`).join(", ");
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Analyze these expenses: ${summary}. Provide a prediction and a tip.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          prediction: { type: Type.STRING },
          tip: { type: Type.STRING }
        },
        required: ["prediction", "tip"]
      }
    }
  });
  return JSON.parse(response.text || "{}");
};
