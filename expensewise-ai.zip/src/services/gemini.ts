import { GoogleGenAI, Type } from "@google/genai";
import { Expense, AIInsight } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });

export const extractExpense = async (input: string | { data: string; mimeType: string }): Promise<Partial<Expense>> => {
  const model = ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: typeof input === 'string' 
      ? `Extract expense details from this text: "${input}"`
      : {
          parts: [
            { text: "Extract expense details from this receipt image." },
            { inlineData: input }
          ]
        },
    config: {
      systemInstruction: "You are a Personal Expense Analyzer. Extract Amount, Category, and Merchant. Categories: Food, Travel, Shopping, Bills, Entertainment, Health, Other. Return JSON.",
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          amount: { type: Type.NUMBER },
          category: { type: Type.STRING, enum: ["Food", "Travel", "Shopping", "Bills", "Entertainment", "Health", "Other"] },
          merchant: { type: Type.STRING },
          date: { type: Type.STRING, description: "ISO 8601 date string if found, otherwise today's date." }
        },
        required: ["amount", "category", "merchant"]
      }
    }
  });

  const response = await model;
  return JSON.parse(response.text || "{}");
};

export const getFinancialInsights = async (expenses: Expense[]): Promise<AIInsight> => {
  const expenseSummary = expenses.map(e => `${e.date}: ${e.merchant} - $${e.amount} (${e.category})`).join("\n");
  
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Based on these expenses:\n${expenseSummary}\n\nWhich category is over budget? Provide a prediction for next month and one tip to save money.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          overBudgetCategory: { type: Type.STRING },
          prediction: { type: Type.STRING },
          savingTip: { type: Type.STRING }
        },
        required: ["overBudgetCategory", "prediction", "savingTip"]
      }
    }
  });

  return JSON.parse(response.text || "{}");
};
