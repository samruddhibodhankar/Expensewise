import React, { useState, useEffect, useMemo } from 'react';
import { 
  Plus, 
  Receipt, 
  TrendingUp, 
  LogOut, 
  Upload, 
  Trash2, 
  BrainCircuit,
  DollarSign,
  Calendar,
  ShoppingBag,
  ArrowRight
} from 'lucide-react';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  addDoc, 
  deleteDoc, 
  doc, 
  orderBy,
  getDocFromServer
} from 'firebase/firestore';
import { onAuthStateChanged, User } from 'firebase/auth';
import { 
  PieChart, 
  Pie, 
  Cell, 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  Legend 
} from 'recharts';
import { useDropzone } from 'react-dropzone';
import { format, startOfMonth, endOfMonth, isWithinInterval } from 'date-fns';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

import { db, auth, signIn, logout } from './firebase';
import { Expense, Category, AIInsight } from './types';
import { extractExpense, getFinancialInsights } from './services/gemini';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const CATEGORY_COLORS: Record<Category, string> = {
  Food: '#F87171',
  Travel: '#60A5FA',
  Shopping: '#FBBF24',
  Bills: '#34D399',
  Entertainment: '#A78BFA',
  Health: '#F472B6',
  Other: '#94A3B8'
};

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [textInput, setTextInput] = useState('');
  const [isExtracting, setIsExtracting] = useState(false);
  const [insights, setInsights] = useState<AIInsight | null>(null);
  const [isGeneratingInsights, setIsGeneratingInsights] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
    });
    return unsubscribe;
  }, []);

  useEffect(() => {
    if (!user) {
      setExpenses([]);
      return;
    }

    const q = query(
      collection(db, 'expenses'),
      where('userId', '==', user.uid),
      orderBy('date', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Expense[];
      setExpenses(data);
    }, (error) => {
      console.error("Firestore error:", error);
    });

    return unsubscribe;
  }, [user]);

  // Test connection on boot
  useEffect(() => {
    const testConnection = async () => {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if (error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Firebase connection error. Check your configuration.");
        }
      }
    };
    testConnection();
  }, []);

  const handleTextSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!textInput.trim() || !user) return;

    setIsExtracting(true);
    try {
      const extracted = await extractExpense(textInput);
      await addDoc(collection(db, 'expenses'), {
        ...extracted,
        date: extracted.date || new Date().toISOString(),
        userId: user.uid,
        rawInput: textInput
      });
      setTextInput('');
    } catch (error) {
      console.error("Extraction error:", error);
    } finally {
      setIsExtracting(false);
    }
  };

  const onDrop = async (acceptedFiles: File[]) => {
    if (acceptedFiles.length === 0 || !user) return;

    setIsExtracting(true);
    try {
      const file = acceptedFiles[0];
      const reader = new FileReader();
      reader.onload = async () => {
        const base64 = (reader.result as string).split(',')[1];
        const extracted = await extractExpense({ data: base64, mimeType: file.type });
        await addDoc(collection(db, 'expenses'), {
          ...extracted,
          date: extracted.date || new Date().toISOString(),
          userId: user.uid,
          rawInput: `Image: ${file.name}`
        });
      };
      reader.readAsDataURL(file);
    } catch (error) {
      console.error("Image extraction error:", error);
    } finally {
      setIsExtracting(false);
    }
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ 
    onDrop, 
    accept: { 'image/*': [] },
    multiple: false 
  } as any);

  const deleteExpense = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'expenses', id));
    } catch (error) {
      console.error("Delete error:", error);
    }
  };

  const generateInsights = async () => {
    if (expenses.length === 0) return;
    setIsGeneratingInsights(true);
    try {
      const result = await getFinancialInsights(expenses);
      setInsights(result);
    } catch (error) {
      console.error("Insights error:", error);
    } finally {
      setIsGeneratingInsights(false);
    }
  };

  const chartData = useMemo(() => {
    const categories: Record<string, number> = {};
    expenses.forEach(e => {
      categories[e.category] = (categories[e.category] || 0) + e.amount;
    });
    return Object.entries(categories).map(([name, value]) => ({ name, value }));
  }, [expenses]);

  const dailyData = useMemo(() => {
    const days: Record<string, number> = {};
    const now = new Date();
    const start = startOfMonth(now);
    const end = endOfMonth(now);

    expenses
      .filter(e => isWithinInterval(new Date(e.date), { start, end }))
      .forEach(e => {
        const day = format(new Date(e.date), 'MMM dd');
        days[day] = (days[day] || 0) + e.amount;
      });

    return Object.entries(days)
      .sort((a, b) => new Date(a[0]).getTime() - new Date(b[0]).getTime())
      .map(([name, value]) => ({ name, value }));
  }, [expenses]);

  const totalSpent = useMemo(() => expenses.reduce((sum, e) => sum + e.amount, 0), [expenses]);

  if (loading) {
    return (
      <div className="min-h-screen bg-stone-50 flex items-center justify-center">
        <div className="animate-pulse flex flex-col items-center gap-4">
          <div className="w-12 h-12 bg-emerald-500 rounded-full" />
          <p className="font-mono text-xs text-stone-400 uppercase tracking-widest">Loading ExpenseWise...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-[#E4E3E0] flex flex-col">
        <header className="p-8 flex justify-between items-center border-b border-stone-900/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-stone-900 rounded-xl flex items-center justify-center">
              <Receipt className="text-white w-6 h-6" />
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-stone-900">ExpenseWise AI</h1>
          </div>
        </header>

        <main className="flex-1 flex flex-col items-center justify-center p-8 text-center max-w-2xl mx-auto">
          <div className="mb-12">
            <h2 className="text-6xl font-black text-stone-900 leading-[0.9] mb-6 uppercase tracking-tighter">
              Track Smarter.<br />Save Faster.
            </h2>
            <p className="text-lg text-stone-600 font-medium">
              The AI-powered expense analyzer that turns your receipts into actionable financial insights.
            </p>
          </div>

          <button 
            onClick={signIn}
            className="group relative flex items-center gap-4 bg-stone-900 text-white px-8 py-4 rounded-2xl font-bold hover:bg-stone-800 transition-all shadow-xl hover:shadow-2xl active:scale-95"
          >
            <span>Get Started with Google</span>
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>

          <div className="mt-24 grid grid-cols-3 gap-12 w-full">
            {[
              { icon: BrainCircuit, label: "AI Extraction", desc: "Scan receipts instantly" },
              { icon: TrendingUp, label: "Smart Insights", desc: "Personalized saving tips" },
              { icon: DollarSign, label: "Budgeting", desc: "Visualize your spending" }
            ].map((feature, i) => (
              <div key={i} className="flex flex-col items-center gap-3">
                <div className="w-12 h-12 bg-white rounded-2xl shadow-sm flex items-center justify-center border border-stone-200">
                  <feature.icon className="w-6 h-6 text-stone-900" />
                </div>
                <h3 className="font-bold text-sm text-stone-900">{feature.label}</h3>
                <p className="text-xs text-stone-500">{feature.desc}</p>
              </div>
            ))}
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-stone-50 text-stone-900 font-sans">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-stone-200 px-6 py-4 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-stone-900 rounded-lg flex items-center justify-center">
            <Receipt className="text-white w-5 h-5" />
          </div>
          <span className="font-bold tracking-tight">ExpenseWise</span>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="text-right hidden sm:block">
            <p className="text-xs font-bold text-stone-900">{user.displayName}</p>
            <p className="text-[10px] text-stone-400 font-mono uppercase">{user.email}</p>
          </div>
          <button 
            onClick={logout}
            className="p-2 hover:bg-stone-100 rounded-lg transition-colors text-stone-400 hover:text-red-500"
          >
            <LogOut className="w-5 h-5" />
          </button>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Input & Insights */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* AI Input Card */}
          <section className="bg-white rounded-3xl p-6 shadow-sm border border-stone-200">
            <div className="flex items-center gap-2 mb-6">
              <div className="w-8 h-8 bg-emerald-50 rounded-lg flex items-center justify-center">
                <Plus className="text-emerald-600 w-5 h-5" />
              </div>
              <h2 className="font-bold">Add Expense</h2>
            </div>

            <form onSubmit={handleTextSubmit} className="space-y-4">
              <div className="relative">
                <textarea
                  value={textInput}
                  onChange={(e) => setTextInput(e.target.value)}
                  placeholder="e.g., Spent $15 at Starbucks for coffee"
                  className="w-full h-24 p-4 bg-stone-50 border border-stone-200 rounded-2xl text-sm focus:ring-2 focus:ring-stone-900 focus:border-transparent transition-all resize-none"
                  disabled={isExtracting}
                />
                <button 
                  type="submit"
                  disabled={isExtracting || !textInput.trim()}
                  className="absolute bottom-3 right-3 p-2 bg-stone-900 text-white rounded-xl disabled:opacity-50 disabled:cursor-not-allowed hover:bg-stone-800 transition-all"
                >
                  {isExtracting ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <ArrowRight className="w-5 h-5" />}
                </button>
              </div>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-stone-100"></div>
                </div>
                <div className="relative flex justify-center text-xs uppercase tracking-widest font-mono text-stone-300 bg-white px-2">
                  or upload receipt
                </div>
              </div>

              <div 
                {...getRootProps()} 
                className={cn(
                  "border-2 border-dashed rounded-2xl p-8 text-center transition-all cursor-pointer",
                  isDragActive ? "border-emerald-500 bg-emerald-50" : "border-stone-200 hover:border-stone-300 bg-stone-50/50"
                )}
              >
                <input {...getInputProps()} />
                <Upload className="w-8 h-8 text-stone-400 mx-auto mb-2" />
                <p className="text-xs font-medium text-stone-500">Drop receipt image here</p>
              </div>
            </form>
          </section>

          {/* AI Advisor Card */}
          <section className="bg-stone-900 rounded-3xl p-6 text-white overflow-hidden relative">
            <div className="relative z-10">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-2">
                  <BrainCircuit className="text-emerald-400 w-5 h-5" />
                  <h2 className="font-bold">AI Financial Advisor</h2>
                </div>
                <button 
                  onClick={generateInsights}
                  disabled={isGeneratingInsights || expenses.length === 0}
                  className="text-[10px] uppercase tracking-widest font-mono bg-white/10 hover:bg-white/20 px-3 py-1 rounded-full transition-colors disabled:opacity-50"
                >
                  {isGeneratingInsights ? 'Analyzing...' : 'Refresh'}
                </button>
              </div>

              {insights ? (
                <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                  <div>
                    <p className="text-[10px] uppercase tracking-widest text-emerald-400 mb-1 font-mono">Top Concern</p>
                    <p className="text-xl font-bold leading-tight">{insights.overBudgetCategory}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase tracking-widest text-emerald-400 mb-1 font-mono">Prediction</p>
                    <p className="text-sm text-stone-300 leading-relaxed">{insights.prediction}</p>
                  </div>
                  <div className="bg-white/5 p-4 rounded-2xl border border-white/10">
                    <p className="text-[10px] uppercase tracking-widest text-emerald-400 mb-2 font-mono">Saving Tip</p>
                    <p className="text-sm italic text-stone-200">"{insights.savingTip}"</p>
                  </div>
                </div>
              ) : (
                <div className="py-12 text-center">
                  <p className="text-sm text-stone-400">Add some expenses to get personalized AI insights.</p>
                </div>
              )}
            </div>
            
            {/* Decorative background element */}
            <div className="absolute -right-12 -bottom-12 w-48 h-48 bg-emerald-500/10 blur-3xl rounded-full" />
          </section>
        </div>

        {/* Right Column: Dashboard & List */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm">
              <p className="text-[10px] uppercase tracking-widest text-stone-400 font-mono mb-1">Total Spent</p>
              <p className="text-3xl font-bold text-stone-900">${totalSpent.toFixed(2)}</p>
            </div>
            <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm">
              <p className="text-[10px] uppercase tracking-widest text-stone-400 font-mono mb-1">Transactions</p>
              <p className="text-3xl font-bold text-stone-900">{expenses.length}</p>
            </div>
            <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm">
              <p className="text-[10px] uppercase tracking-widest text-stone-400 font-mono mb-1">Top Category</p>
              <p className="text-3xl font-bold text-stone-900">
                {chartData.length > 0 ? chartData.sort((a, b) => b.value - a.value)[0].name : '--'}
              </p>
            </div>
          </div>

          {/* Charts */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm min-h-[300px]">
              <h3 className="text-sm font-bold mb-6">Spending by Category</h3>
              <div className="h-[200px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={chartData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {chartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={CATEGORY_COLORS[entry.name as Category] || '#94A3B8'} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm min-h-[300px]">
              <h3 className="text-sm font-bold mb-6">Daily Spending (This Month)</h3>
              <div className="h-[200px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={dailyData}>
                    <XAxis dataKey="name" fontSize={10} tickLine={false} axisLine={false} />
                    <YAxis fontSize={10} tickLine={false} axisLine={false} />
                    <Tooltip 
                      cursor={{ fill: '#F5F5F4' }}
                      contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                    />
                    <Bar dataKey="value" fill="#1C1917" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Expense List */}
          <section className="bg-white rounded-3xl border border-stone-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-stone-100 flex justify-between items-center">
              <h3 className="font-bold">Recent Transactions</h3>
              <div className="flex gap-2">
                <Calendar className="w-4 h-4 text-stone-400" />
                <span className="text-xs text-stone-400 font-medium">All Time</span>
              </div>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-stone-50/50 text-[10px] uppercase tracking-widest text-stone-400 font-mono">
                    <th className="px-6 py-4 font-medium">Date</th>
                    <th className="px-6 py-4 font-medium">Merchant</th>
                    <th className="px-6 py-4 font-medium">Category</th>
                    <th className="px-6 py-4 font-medium text-right">Amount</th>
                    <th className="px-6 py-4 font-medium text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {expenses.length > 0 ? expenses.map((expense) => (
                    <tr key={expense.id} className="group hover:bg-stone-50/50 transition-colors">
                      <td className="px-6 py-4">
                        <p className="text-sm font-medium">{format(new Date(expense.date), 'MMM dd, yyyy')}</p>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-stone-100 flex items-center justify-center">
                            <ShoppingBag className="w-4 h-4 text-stone-500" />
                          </div>
                          <p className="text-sm font-bold text-stone-900">{expense.merchant}</p>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span 
                          className="px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider"
                          style={{ 
                            backgroundColor: `${CATEGORY_COLORS[expense.category]}20`,
                            color: CATEGORY_COLORS[expense.category]
                          }}
                        >
                          {expense.category}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <p className="text-sm font-bold text-stone-900">${expense.amount.toFixed(2)}</p>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <button 
                          onClick={() => expense.id && deleteExpense(expense.id)}
                          className="p-2 text-stone-300 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  )) : (
                    <tr>
                      <td colSpan={5} className="px-6 py-12 text-center text-stone-400 text-sm italic">
                        No transactions found. Start by adding one above!
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}
