export type Category = 'Food' | 'Travel' | 'Shopping' | 'Bills' | 'Entertainment' | 'Health' | 'Other';

export interface Expense {
  id?: string;
  amount: number;
  category: Category;
  merchant: string;
  date: string;
  userId: string;
  rawInput?: string;
}

export interface AIInsight {
  overBudgetCategory: string;
  prediction: string;
  savingTip: string;
}
